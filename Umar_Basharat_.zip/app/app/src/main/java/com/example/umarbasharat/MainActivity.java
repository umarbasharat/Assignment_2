package com.example.umarbasharat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5,e6,number1;
    Button b1,b2,insert;
    DatabaseHelper db;
    private static final int PICK_IMAGE=100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new DatabaseHelper(this);
        getSupportActionBar().setTitle("Signup Form");
        e1=(EditText)findViewById(R.id.userName);
        e2=(EditText)findViewById(R.id.loginemail);
        e3=(EditText)findViewById(R.id.password);
        e4=(EditText)findViewById(R.id.cpassword);
        e5=(EditText)findViewById(R.id.date);
        e6=(EditText)findViewById(R.id.number);
        b1=(Button)findViewById(R.id.reg);
        b2=(Button)findViewById(R.id.button2);


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,Login.class);
                startActivity(i);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1=e1.getText().toString();
                String s2=e2.getText().toString();
                String s3=e3.getText().toString();
                String s4=e4.getText().toString();
                String s5=e5.getText().toString();
                String s6=e6.getText().toString();
                if(s1.equals(" ")||s2.equals(" ")||s3.equals(" ")||s4.equals(" ")||s5.equals(" ")||s6.equals(" "))
                {
                    Toast.makeText(getApplicationContext(),"Fields are empty",Toast.LENGTH_SHORT).show();
                }
                else  {
                    if(s3.equals(s4)){
                        Boolean chkemail=db.chckemail(s2);

                        if(chkemail==true)
                        {
                            Boolean insert=db.insert(s2,s3);
                            if(insert== true){
                                Toast.makeText(getApplicationContext(),"Registered successfully",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"User already exists",Toast.LENGTH_SHORT).show();
                        }

                    }

                }
            }
        });


      insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_PICK, Uri.parse(
                        "content://media/internal/images/media"
                ));
                startActivityForResult(intent,PICK_IMAGE);
            }
        });

    }
    @Override
    protected  void  onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        if(resultCode==RESULT_OK && requestCode==PICK_IMAGE){
            Uri uri=data.getData();
            String x=getPath(uri);
            Integer num=Integer.parseInt(number1.getText().toString());
            if(db.insertimage(x,num)){
                Toast.makeText(getApplicationContext(),"successfull",Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(getApplicationContext(),"successfull",Toast.LENGTH_SHORT).show();
            }
        }

    }

    public  String getPath(Uri uri){
        if(uri==null)return null;
        String[] projection={MediaStore.Images.Media.DATA};
        Cursor cursor=managedQuery(uri,projection,null,null,null);
        if(cursor!=null){
            int column_indx=cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_indx);
        }
        return uri.getPath();
    }

}

